import os, sqlite3
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'CHANGE-ME-BEFORE-DEPLOYMENT')
DB = os.environ.get('DATABASE_PATH', 'school.db')

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'admin')''')
        con.execute('''CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY, student_no TEXT UNIQUE, name TEXT NOT NULL, father_name TEXT, grade TEXT, section TEXT, guardian_phone TEXT, notes TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        con.execute('''CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL, date TEXT NOT NULL, status TEXT NOT NULL, UNIQUE(student_id,date), FOREIGN KEY(student_id) REFERENCES students(id))''')
        con.execute('''CREATE TABLE IF NOT EXISTS fees(id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL, amount REAL NOT NULL, paid REAL NOT NULL DEFAULT 0, month TEXT, note TEXT, FOREIGN KEY(student_id) REFERENCES students(id))''')
        con.execute('''CREATE TABLE IF NOT EXISTS grades(id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL, subject TEXT, exam_name TEXT, score REAL, max_score REAL DEFAULT 100, FOREIGN KEY(student_id) REFERENCES students(id))''')
        con.execute('''CREATE TABLE IF NOT EXISTS staff(id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT, subject TEXT, role TEXT, notes TEXT)''')
        con.commit()

def login_required(fn):
    @wraps(fn)
    def inner(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return inner

@app.route('/setup', methods=['GET','POST'])
def setup():
    with db() as con:
        count = con.execute('SELECT COUNT(*) n FROM users').fetchone()['n']
    if count:
        return redirect(url_for('login'))
    if request.method == 'POST':
        username = request.form.get('username','').strip()
        password = request.form.get('password','')
        if len(username) < 3 or len(password) < 10:
            flash('کارن‌نوم لږ تر لږه ۳ توري او پاسورډ لږ تر لږه ۱۰ توري ولري.')
        else:
            with db() as con:
                con.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)',(username,generate_password_hash(password),'admin'))
                con.commit()
            flash('د مدیر حساب جوړ شو؛ اوس Login وکړئ.')
            return redirect(url_for('login'))
    return render_template('setup.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        u=request.form.get('username','').strip(); p=request.form.get('password','')
        with db() as con:
            user=con.execute('SELECT * FROM users WHERE username=?',(u,)).fetchone()
        if user and check_password_hash(user['password_hash'],p):
            session.clear(); session['user_id']=user['id']; session['username']=user['username']; session['role']=user['role']
            return redirect(url_for('dashboard'))
        flash('کارن‌نوم یا پاسورډ ناسم دی.')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear(); return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard():
    with db() as con:
        n=con.execute('SELECT COUNT(*) n FROM students').fetchone()['n']
        staff=con.execute('SELECT COUNT(*) n FROM staff').fetchone()['n']
        recent=con.execute('SELECT * FROM students ORDER BY id DESC LIMIT 8').fetchall()
    return render_template('dashboard.html', student_count=n, staff_count=staff, recent=recent)

@app.route('/students')
@login_required
def students():
    q=request.args.get('q','').strip()
    with db() as con:
        if q:
            rows=con.execute('SELECT * FROM students WHERE name LIKE ? OR father_name LIKE ? OR student_no LIKE ? ORDER BY id DESC', (f'%{q}%',f'%{q}%',f'%{q}%')).fetchall()
        else:
            rows=con.execute('SELECT * FROM students ORDER BY id DESC').fetchall()
    return render_template('students.html', rows=rows, q=q)

@app.route('/students/new', methods=['GET','POST'])
@login_required
def student_new():
    if request.method=='POST':
        fields=[request.form.get(k,'').strip() for k in ['student_no','name','father_name','grade','section','guardian_phone','notes']]
        if not fields[1]: flash('د زده‌کوونکي نوم اړین دی.')
        else:
            try:
                with db() as con:
                    con.execute('INSERT INTO students(student_no,name,father_name,grade,section,guardian_phone,notes) VALUES(?,?,?,?,?,?,?)',fields); con.commit()
                flash('زده‌کوونکی ثبت شو.'); return redirect(url_for('students'))
            except sqlite3.IntegrityError:
                flash('دا د زده‌کوونکي شمېره مخکې ثبت شوې؛ بله شمېره ورکړئ.')
    return render_template('student_form.html')

@app.route('/students/<int:sid>/delete', methods=['POST'])
@login_required
def student_delete(sid):
    with db() as con:
        con.execute('DELETE FROM attendance WHERE student_id=?',(sid,)); con.execute('DELETE FROM fees WHERE student_id=?',(sid,)); con.execute('DELETE FROM grades WHERE student_id=?',(sid,)); con.execute('DELETE FROM students WHERE id=?',(sid,)); con.commit()
    flash('د زده‌کوونکي ریکارډ حذف شو.'); return redirect(url_for('students'))

if __name__=='__main__':
    init_db()
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)
