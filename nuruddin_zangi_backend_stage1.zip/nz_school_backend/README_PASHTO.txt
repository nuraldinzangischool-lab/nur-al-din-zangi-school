نورالدین زنګي ښوونځي آنلاین مدیریت سیستم — Backend لومړنۍ نسخه

دا پروژه د Flask + SQLite د پیل نسخه ده. Login، د مدیر د حساب Setup، Dashboard، د زده‌کوونکو ثبت/لټون/حذف، او د راتلونکو برخو لپاره Database جدولونه پکې شامل دي.

په کمپیوټر کې محلي چلول:
1) Python 3 نصب کړئ.
2) په Terminal/Command Prompt کې د پروژې فولډر ته لاړ شئ.
3) اجرا کړئ: pip install -r requirements.txt
4) اجرا کړئ: python app.py
5) په براوزر کې پر http://127.0.0.1:5000/setup لاړ شئ او مدیر جوړ کړئ.

Render نشر:
- Build Command: pip install -r requirements.txt
- Start Command: gunicorn app:app
- Environment Variable: SECRET_KEY = یو اوږد تصادفي پټ متن
- د SQLite لپاره د Render Persistent Disk اړین دی او DATABASE_PATH باید د Disk mount path دننه وي (مثلاً /var/data/school.db). د Disk mount path باید /var/data وي.

امنیتي یادښت:
دا Starter نسخه ده. مخکې له حقیقي زده‌کوونکو معلوماتو استعمال، HTTPS، CSRF protection، rate limiting، د کارکوونکو صلاحیتونه، د ډیټابېس backup، او د سرور persistent storage باید تنظیم او ازمویل شي. د SECRET_KEY حتماً بدل کړئ.
