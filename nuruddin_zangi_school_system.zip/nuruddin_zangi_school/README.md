# Nuruddin Zangi School Management (starter MVP)
Pashto/RTL Flask + SQLite school management starter: login, dashboard, student records, teacher records, attendance, fee entries, and exam scores.

## Local run
1. Install Python 3.10+.
2. `pip install -r requirements.txt`
3. `python app.py`
4. Open `http://localhost:5000`

Default login: `admin` / `Admin12345` — change this before any public deployment. Also set a strong `SECRET_KEY` environment variable.

## Render deployment
- Create a Web Service connected to this Git repository.
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- For persistent database storage, configure a persistent disk and set `DATABASE_PATH` to a file path on that disk. SQLite on ephemeral storage may lose data after deploy/restart.

This is an initial MVP, not yet a fully audited production system. It needs password change UI, backup/export, role permissions, secure deployment configuration, and testing before real school records are entered.
