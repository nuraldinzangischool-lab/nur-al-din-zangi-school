from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'change-this-secret-key-before-deployment')
DB = os.environ.get('DATABASE_PATH', 'school.db')

def db():
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row; return con

def init_db():
    con=db(); c=con.cursor()
    c.execute('CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY, name TEXT NOT NULL, father TEXT, grade TEXT, phone TEXT, address TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
    c.execute('CREATE TABLE IF NOT EXISTS teachers(id INTEGER PRIMARY KEY, name TEXT NOT NULL, subject TEXT, phone TEXT, address TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY, student_id INTEGER, date TEXT, status TEXT, UNIQUE(student_id,date), FOREIGN KEY(student_id) REFERENCES students(id))')
    c.execute('CREATE TABLE IF NOT EXISTS fees(id INTEGER PRIMARY KEY, student_id INTEGER, amount REAL, date TEXT, note TEXT, FOREIGN KEY(student_id) REFERENCES students(id))')
    c.execute('CREATE TABLE IF NOT EXISTS grades(id INTEGER PRIMARY KEY, student_id INTEGER, subject TEXT, exam TEXT, score REAL, date TEXT, FOREIGN KEY(student_id) REFERENCES students(id))')
    if not c.execute('SELECT id FROM users').fetchone(): c.execute('INSERT INTO users(username,password_hash) VALUES(?,?)',('admin',generate_password_hash('Admin12345')))
    con.commit(); con.close()

@app.before_request
def ready(): init_db()

def login_required(): return session.get('user')
@app.route('/', methods=['GET','POST'])
def login():
    if login_required(): return redirect(url_for('dashboard'))
    if request.method=='POST':
        con=db(); u=con.execute('SELECT * FROM users WHERE username=?',(request.form.get('username',''),)).fetchone(); con.close()
        if u and check_password_hash(u['password_hash'],request.form.get('password','')):
            session['user']=u['username']; return redirect(url_for('dashboard'))
        flash('د کارن نوم یا پټنوم ناسم دی.')
    return render_template('login.html')
@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))
@app.route('/dashboard')
def dashboard():
    if not login_required(): return redirect(url_for('login'))
    con=db(); counts={t:con.execute(f'SELECT COUNT(*) n FROM {t}').fetchone()['n'] for t in ['students','teachers','attendance','fees','grades']}; con.close()
    return render_template('dashboard.html',counts=counts)
@app.route('/students', methods=['GET','POST'])
def students():
    if not login_required(): return redirect(url_for('login'))
    con=db()
    if request.method=='POST':
        con.execute('INSERT INTO students(name,father,grade,phone,address) VALUES(?,?,?,?,?)',tuple(request.form.get(k,'') for k in ['name','father','grade','phone','address'])); con.commit(); flash('زده‌کوونکی ثبت شو.')
    rows=con.execute('SELECT * FROM students ORDER BY id DESC').fetchall(); con.close(); return render_template('students.html',rows=rows)
@app.route('/students/delete/<int:id>', methods=['POST'])
def student_delete(id):
    if not login_required(): return redirect(url_for('login'))
    con=db(); con.execute('DELETE FROM attendance WHERE student_id=?',(id,)); con.execute('DELETE FROM fees WHERE student_id=?',(id,)); con.execute('DELETE FROM grades WHERE student_id=?',(id,)); con.execute('DELETE FROM students WHERE id=?',(id,)); con.commit(); con.close(); flash('د زده‌کوونکي ریکارډ حذف شو.'); return redirect(url_for('students'))
@app.route('/teachers', methods=['GET','POST'])
def teachers():
    if not login_required(): return redirect(url_for('login'))
    con=db()
    if request.method=='POST': con.execute('INSERT INTO teachers(name,subject,phone,address) VALUES(?,?,?,?)',tuple(request.form.get(k,'') for k in ['name','subject','phone','address'])); con.commit(); flash('استاد ثبت شو.')
    rows=con.execute('SELECT * FROM teachers ORDER BY id DESC').fetchall(); con.close(); return render_template('teachers.html',rows=rows)
@app.route('/attendance', methods=['GET','POST'])
def attendance():
    if not login_required(): return redirect(url_for('login'))
    con=db(); students=con.execute('SELECT * FROM students ORDER BY name').fetchall()
    if request.method=='POST':
        date=request.form.get('date');
        for s in students:
            status=request.form.get(f's_{s["id"]}')
            if status: con.execute('INSERT OR REPLACE INTO attendance(student_id,date,status) VALUES(?,?,?)',(s['id'],date,status))
        con.commit(); flash('حاضري ثبت شوه.')
    date=request.args.get('date',''); rows=con.execute('SELECT a.*,s.name,s.grade FROM attendance a JOIN students s ON s.id=a.student_id WHERE a.date=? ORDER BY s.name',(date,)).fetchall() if date else []
    con.close(); return render_template('attendance.html',students=students,rows=rows,date=date)
@app.route('/fees', methods=['GET','POST'])
def fees():
    if not login_required(): return redirect(url_for('login'))
    con=db(); students=con.execute('SELECT * FROM students ORDER BY name').fetchall()
    if request.method=='POST': con.execute('INSERT INTO fees(student_id,amount,date,note) VALUES(?,?,?,?)',(request.form.get('student_id'),request.form.get('amount'),request.form.get('date'),request.form.get('note'))); con.commit(); flash('فیس ثبت شو.')
    rows=con.execute('SELECT f.*,s.name FROM fees f JOIN students s ON s.id=f.student_id ORDER BY f.id DESC').fetchall(); total=con.execute('SELECT COALESCE(SUM(amount),0) total FROM fees').fetchone()['total']; con.close(); return render_template('fees.html',students=students,rows=rows,total=total)
@app.route('/grades', methods=['GET','POST'])
def grades():
    if not login_required(): return redirect(url_for('login'))
    con=db(); students=con.execute('SELECT * FROM students ORDER BY name').fetchall()
    if request.method=='POST': con.execute('INSERT INTO grades(student_id,subject,exam,score,date) VALUES(?,?,?,?,?)',(request.form.get('student_id'),request.form.get('subject'),request.form.get('exam'),request.form.get('score'),request.form.get('date'))); con.commit(); flash('نمره ثبت شوه.')
    rows=con.execute('SELECT g.*,s.name FROM grades g JOIN students s ON s.id=g.student_id ORDER BY g.id DESC').fetchall(); con.close(); return render_template('grades.html',students=students,rows=rows)
if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)))
